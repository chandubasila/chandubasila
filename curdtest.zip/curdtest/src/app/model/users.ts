export class Users {
    // ID:number
    Name: string;
    Email: string;
    Class: string;
    Year: string;
    City: string;
    Country: string;
}